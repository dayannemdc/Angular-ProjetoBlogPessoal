export const environment = {
  production: true,
  token: '',
  nome: '',
  idUsuario: 0,
  foto: ''
};
