export class UserLogin{
    public email: string
    public senha: string
    public idUsuario: number
    public nome: string
    public token: string
    public foto: string
    public tipo: string
}